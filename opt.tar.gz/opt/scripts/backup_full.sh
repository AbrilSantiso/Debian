#!/bin/bash

# backup_full.sh - Script de backup general
# Guarda backups con nombre con fecha, validando origen y destino
# Autor: Abril y equipo

ORIGEN=$1
DESTINO="/backup_dir"

# Obtener fecha en formato YYYYMMDD
FECHA=$(date +%Y%m%d)

# Mostrar ayuda si se pide
if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  echo "Uso: $0 <origen>"
  echo "Ejemplo: $0 /var/log"
  exit 0
fi

# Validar parámetros
if [[ -z "$ORIGEN" ]]; then
  echo "[ERROR] Debe indicar el directorio de origen"
  exit 1
fi

# Validar existencia de origen y destino
if [[ ! -d "$ORIGEN" ]]; then
  echo "[ERROR] El directorio de origen no existe: $ORIGEN"
  exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
  echo "[ERROR] El directorio de destino no existe: $DESTINO"
  exit 1
fi

# Nombre del archivo de backup
BASE=$(basename "$ORIGEN")
ARCHIVO="${BASE}_bkp_${FECHA}.tar.gz"

# Crear backup
tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

if [[ $? -eq 0 ]]; then
  echo "Backup creado correctamente: $DESTINO/$ARCHIVO"
else
  echo "[ERROR] No se pudo crear el backup"
  exit 1
fi

